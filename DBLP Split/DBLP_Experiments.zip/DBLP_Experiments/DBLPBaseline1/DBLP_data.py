import torch
import zipfile
import networkx as nx
import pandas as pd
import numpy as np
import itertools
import os
import pandas as pd
import matplotlib.pyplot as plt


class HeterogeneousGraphData():
    def __init__(self):
        super().__init__()
        self.node_feature_dict = None
        self.message_edge_dict = None
        self.predict_edge_dict = None
        self.unseen_node_type = None
        self.index2node_dict = None
        self.node2index_dict = None

    def to(self, device):
        for k, v in self.node_feature_dict.items():
            self.node_feature_dict[k] = v.to(device)
        for k, v in self.message_edge_dict.items():
            self.message_edge_dict[k] = v.to(device)
        for k, v in self.predict_edge_dict.items():
            self.predict_edge_dict[k] = v.to(device)

class DBLPDataset():
    def __init__(self, dataset: str = 'dblp'):
        super().__init__()
        self.metapath_dict = dict()
        self.dataset = dataset
        dir = f'./DBLP/'
        save_path = os.path.join(dir, f'{dataset}.pth')
        if os.path.exists(save_path):
            self.data_list = self.load(file_path=save_path)
        else:
            self.data_list = self.read(dir=dir)
            self.save(data_list=self.data_list, file_path=save_path)

        print('Done')

    def zip(self, dir):
        for zip in os.listdir(dir):
            if zip.endswith(".zip"):
                zipfile_path = os.path.join(dir, zip)
                with zipfile.ZipFile(zipfile_path, 'r') as zip_ref:
                    zip_ref.extractall(dir)

    def read(self, dir):
        self.zip(dir=dir)

        data_list = []
        for fold in os.listdir(dir):
            if fold.endswith(".zip"): continue

            if 'paper' in fold:
                unseen_node_type = 'paper'
            else:
                continue

            fold_path = os.path.join(dir, fold)

            train_val_test = []
            for tvt in ['train', 'valid', 'test']:
                node_feature_dict = {}
                message_edge_dict = {}
                predict_edge_dict = {}

                # node feature
                tvt_path = os.path.join(dir, fold, tvt)
                for file in os.listdir(tvt_path):
                    if not file.lower().endswith(('.csv', '.xlsx', '.xls')): continue
                    if 'feature' in file:
                        file_path = os.path.join(dir, fold, tvt, file)
                        node_feature = self.excel(file_name=file, file_path=file_path)
                        node_type = node_feature.columns[0]
                        node_feature_dict[node_type] = node_feature
                    if 'message' in file:
                        file_path = os.path.join(dir, fold, tvt, file)
                        message_edge = self.excel(file_name=file, file_path=file_path)
                        edge_type = tuple(message_edge.columns)
                        assert len(edge_type) == 2
                        message_edge_dict[edge_type] = message_edge
                    if 'predict' in file:
                        file_path = os.path.join(dir, fold, tvt, file)
                        predict_edge = self.excel(file_name=file, file_path=file_path)
                        edge_type = tuple(predict_edge.columns)
                        assert len(edge_type) == 2
                        predict_edge_dict[edge_type] = predict_edge

                # node index
                node2index_dict = dict()
                index2node_dict = dict()
                for node_type, node_feature in node_feature_dict.items():
                    index2node_dict[node_type] = node_feature[node_type].to_dict()
                    node2index_dict[node_type] = pd.Series(data=node_feature.index,
                                                           index=node_feature[node_type].values).to_dict()
                # node feature
                for node_type, node_feature in node_feature_dict.items():
                    node_feature_dict[node_type] = node_feature[node_feature.columns[1:]].values.astype(float)

                # message edge
                for edge_type, message_edge in message_edge_dict.items():
                    message_edge_dict = self.get_edge(edge_dict=message_edge_dict,
                                                      edge_dataframe=message_edge,
                                                      node2index_dict=node2index_dict)
                # message_edge_dict = self.add_reverse(edge_dict=message_edge_dict)

                # predict edge
                for edge_type, predict_edge in predict_edge_dict.items():
                    predict_edge_dict = self.get_edge(edge_dict=predict_edge_dict,
                                                      edge_dataframe=predict_edge,
                                                      node2index_dict=node2index_dict)
                # predict_edge_dict = self.add_reverse(edge_dict=predict_edge_dict)

                # hetero graph
                hetero_graph = HeterogeneousGraphData()

                node_feature_dict = {k: torch.tensor(v, dtype=torch.float32) for k, v in node_feature_dict.items()}
                message_edge_dict = {k: torch.tensor(v, dtype=torch.int64) for k, v in message_edge_dict.items()}
                predict_edge_dict = {k: torch.tensor(v, dtype=torch.int64) for k, v in predict_edge_dict.items()}

                hetero_graph.node_feature_dict = node_feature_dict
                hetero_graph.message_edge_dict = message_edge_dict
                hetero_graph.predict_edge_dict = predict_edge_dict
                hetero_graph.unseen_node_type = unseen_node_type
                hetero_graph.node2index_dict = node2index_dict
                hetero_graph.index2node_dict = index2node_dict
                train_val_test.append(hetero_graph)

            data_list.append(train_val_test)

        print('data.py Done!')
        return data_list

    def excel(self, file_name, file_path):
        print(f'Reading... {file_path}')
        if file_name.endswith('.csv'):
            try:
                df = pd.read_csv(file_path, na_filter=False)
            except Exception as e:
                print(f"Error reading {file_name}: {e}")
        elif file_name.endswith(('.xls', '.xlsx')):
            try:
                df = pd.read_excel(file_path, na_filter=False)
            except Exception as e:
                print(f"Error reading {file_name}: {e}")

        df = df.replace('', np.nan)
        print('Reading Successful')
        return df

    def add_reverse(self, edge_dict):
        out_dict = dict()
        for edge_type, edge_index in edge_dict.items():
            source_type = edge_type[0]
            target_type = edge_type[1]
            reverse_edge_type = (target_type, source_type)

            if edge_type in edge_dict.keys() and reverse_edge_type in edge_dict.keys():
                continue

            source_index = edge_index[0]
            target_index = edge_index[1]
            reverse_edge_index = [target_index, source_index]
            reverse_edge_index = np.array(reverse_edge_index)

            out_dict[edge_type] = edge_index
            out_dict[reverse_edge_type] = reverse_edge_index

        return out_dict

    def get_edge(self, edge_dict, edge_dataframe, node2index_dict):
        edge_type = tuple(edge_dataframe.columns)
        edge = edge_dataframe.copy()

        for node_type in edge.columns:
            edge[node_type] = edge[node_type].map(node2index_dict[node_type])
            is_all_int = np.issubdtype(edge[node_type].values.dtype, np.integer)
            assert is_all_int

        edge_dict[edge_type] = edge.values.astype(int).T

        return edge_dict

    def save(self, data_list, file_path):
        torch.save(data_list, file_path)

    def load(self, file_path):
        data_list = torch.load(file_path)

        return data_list

    def get_metapath(self):
        self.metapath_dict['paper'] = [[('paper', 'author'), ('author', 'paper')],
                                       [('paper', 'conference'), ('conference', 'paper')],
                                       [('paper', 'term'), ('term', 'paper')],
                                       ]
        self.metapath_dict['term'] = [[('term', 'paper'), ('paper', 'term')]]



        return self.metapath_dict

dblp = DBLPDataset()
data_list = dblp.data_list[0]
train_graph,valid_graph,test_graph = data_list
print()

